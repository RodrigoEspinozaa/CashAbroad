
const readline = require('readline');
const Inventory = require('./inventory');


const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

const inventory = new Inventory();
let isRunning = true;


const colors = {
  error: '\x1b[31m', 
  success: '\x1b[32m', 
  info: '\x1b[36m', 
  reset: '\x1b[0m' 
};


function showMenu() {
  console.log('\n=== GESTIÓN DE INVENTARIO ===');
  console.log('1. Agregar producto');
  console.log('2. Eliminar producto');
  console.log('3. Actualizar cantidad');
  console.log('4. Ver inventario completo');
  console.log('5. Buscar producto');
  console.log('6. Salir');
  console.log('============================');
  rl.question('Seleccione una opción: ', handleMenuChoice);
}


async function handleMenuChoice(choice) {
  if (!isRunning) return;

  try {
    switch (choice.trim()) {
      case '1':
        await handleAddItem();
        break;
      case '2':
        await handleRemoveItem();
        break;
      case '3':
        await handleUpdateItem();
        break;
      case '4':
        showFullInventory();
        break;
      case '5':
        await handleSearchItem();
        break;
      case '6':
        exitApp();
        return;
      default:
        console.log(`${colors.error}❌ Opción inválida${colors.reset}`);
    }
  } catch (error) {
    console.log(`${colors.error}❌ Error: ${error.message}${colors.reset}`);
  } finally {
    if (isRunning) showMenu();
  }
}


async function handleAddItem() {
  const name = await askQuestion('Nombre del producto: ');
  const quantity = await askQuestion('Cantidad a agregar: ');
  
  const result = inventory.addItem(name, parseInt(quantity));
  console.log(`${colors.success}✔ ${result.message}${colors.reset}`);
}


async function handleRemoveItem() {
  const name = await askQuestion('Nombre del producto a eliminar: ');
  
  const result = inventory.removeItem(name);
  console.log(`${colors.success}✔ ${result.message}${colors.reset}`);
}


async function handleUpdateItem() {
  const name = await askQuestion('Nombre del producto: ');
  const quantity = await askQuestion('Nueva cantidad: ');
  
  const result = inventory.updateItem(name, parseInt(quantity));
  console.log(`${colors.success}✔ ${result.message}${colors.reset}`);
}


function showFullInventory() {
  console.log(`\n${colors.info}${inventory.displayInventory()}${colors.reset}`);
}


async function handleSearchItem() {
  const name = await askQuestion('Nombre del producto a buscar: ');
  const quantity = inventory.getItem(name);
  
  if (quantity !== null) {
    console.log(`${colors.info}✔ ${name}: ${quantity} unidades${colors.reset}`);
  } else {
    console.log(`${colors.error}❌ Producto no encontrado${colors.reset}`);
  }
}


function askQuestion(question) {
  return new Promise((resolve) => {
    rl.question(question, resolve);
  });
}


function exitApp() {
  isRunning = false;
  console.log('\nGuardando inventario...');
  console.log(`${colors.success}✅ Inventario final:${colors.reset}`);
  showFullInventory();
  rl.close();
  process.exit(0);
}


process.on('SIGINT', () => {
  console.log('\nRecibida señal de interrupción...');
  exitApp();
});


console.log(`${colors.info}🛍️  Sistema de Gestión de Inventario${colors.reset}`);
showMenu();
