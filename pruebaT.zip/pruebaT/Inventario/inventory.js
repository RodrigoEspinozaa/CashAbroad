// inventory.js - Clase completa del inventario
class Inventory {
    constructor(initialInventory = {}) {
      this.inventory = { ...initialInventory };
    }
  
    // Validador interno de nombres
    _validateName(name) {
      if (typeof name !== 'string' || !name.trim()) {
        throw new Error('El nombre debe ser un texto no vacío');
      }
      if (name.length > 100) {
        throw new Error('El nombre no puede exceder 100 caracteres');
      }
    }
  
    // Validador interno de cantidades
    _validateQuantity(quantity) {
      if (typeof quantity !== 'number' || isNaN(quantity)) {
        throw new Error('La cantidad debe ser un número válido');
      }
      if (quantity < 0) {
        throw new Error('La cantidad no puede ser negativa');
      }
    }
  
    // Agrega o actualiza un producto
    addItem(name, quantity) {
      this._validateName(name);
      this._validateQuantity(quantity);
  
      this.inventory[name] = (this.inventory[name] || 0) + quantity;
      return { ...this.inventory };
    }
  
    // Elimina un producto
    removeItem(name) {
      this._validateName(name);
      const newInventory = { ...this.inventory };
      delete newInventory[name];
      this.inventory = newInventory;
      return { ...this.inventory };
    }
  
    // Obtiene un producto específico
    getItem(name) {
      return this.inventory[name] || null;
    }
  }
  
  module.exports = Inventory;