function sanitizeName(name) {
    return name.replace(/[^a-zA-Z0-9 áéíóúñ]/g, '').trim();
  }
  
  module.exports = { sanitizeName };
  // src/security.js
function sanitizeInput(input) {
    return input.toString().trim().replace(/[^a-zA-Z0-9 áéíóúñÁÉÍÓÚÑ.,-]/g, '');
  }
  
  function validateQuantity(qty) {
    if (!Number.isInteger(qty)) throw new Error('Cantidad debe ser entero');
    if (qty < 0) throw new Error('Cantidad no puede ser negativa');
  }
  
  module.exports = { sanitizeInput, validateQuantity };