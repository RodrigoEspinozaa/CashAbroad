// inventory.test.js - Pruebas para la clase Inventory
const { test } = require('node:test');
const assert = require('node:assert/strict');
const Inventory = require('../inventory'); // Asegúrate que la ruta sea correcta

test('Agregar producto nuevo', () => {
  const inv = new Inventory();
  inv.addItem('Laptop', 3);
  assert.equal(inv.getItem('Laptop'), 3);
});

test('Sumar cantidad a producto existente', () => {
  const inv = new Inventory({ 'Mouse': 2 });
  inv.addItem('Mouse', 3);
  assert.equal(inv.getItem('Mouse'), 5);
});

test('Eliminar producto existente', () => {
  const inv = new Inventory({ 'Keyboard': 1 });
  inv.removeItem('Keyboard');
  assert.equal(inv.getItem('Keyboard'), null);
});

test('Error al agregar cantidad negativa', () => {
  const inv = new Inventory();
  assert.throws(() => inv.addItem('Monitor', -1), /no puede ser negativa/);
});

test('Error al agregar nombre vacío', () => {
  const inv = new Inventory();
  assert.throws(() => inv.addItem('', 5), /no vacío/);
});