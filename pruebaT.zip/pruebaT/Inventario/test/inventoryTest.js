// inventory.js - Versión completa sin dependencias externas
class Inventory {
    constructor(initialInventory = {}) {
      this._inventory = { ...initialInventory };
      this._history = [];
    }
  
    /**
     * Agrega o actualiza un producto en el inventario
     * @param {string} name - Nombre del producto
     * @param {number} quantity - Cantidad a agregar
     * @returns {Object} - Estado actual del inventario
     * @throws {Error} - Si los datos son inválidos
     */
    addItem(name, quantity) {
      this._validateName(name);
      this._validateQuantity(quantity);
  
      const currentQty = this._inventory[name] || 0;
      const newQty = currentQty + quantity;
  
      if (newQty < 0) {
        throw new Error(`Cantidad inválida para ${name}: ${newQty}`);
      }
  
      this._inventory[name] = newQty;
      this._logOperation('ADD', name, quantity);
      
      return this._getInventorySnapshot();
    }
  
    /**
     * Elimina un producto del inventario
     * @param {string} name - Nombre del producto
     * @returns {Object} - Estado actual del inventario
     */
    removeItem(name) {
      this._validateName(name);
  
      if (!(name in this._inventory)) {
        return this._getInventorySnapshot();
      }
  
      const deletedItemQty = this._inventory[name];
      delete this._inventory[name];
      this._logOperation('REMOVE', name, deletedItemQty);
  
      return this._getInventorySnapshot();
    }
  
    /**
     * Actualiza la cantidad de un producto
     * @param {string} name - Nombre del producto
     * @param {number} newQuantity - Nueva cantidad
     * @returns {Object} - Estado actual del inventario
     * @throws {Error} - Si el producto no existe o cantidad es inválida
     */
    updateItem(name, newQuantity) {
      this._validateName(name);
      this._validateQuantity(newQuantity);
  
      if (!(name in this._inventory)) {
        throw new Error(`Producto no encontrado: ${name}`);
      }
  
      this._inventory[name] = newQuantity;
      this._logOperation('UPDATE', name, newQuantity);
  
      return this._getInventorySnapshot();
    }
  
    /**
     * Obtiene la cantidad de un producto
     * @param {string} name - Nombre del producto
     * @returns {number|null} - Cantidad o null si no existe
     */
    getItem(name) {
      return name in this._inventory ? this._inventory[name] : null;
    }
  
    /**
     * Obtiene una copia segura del inventario
     * @returns {Object} - Copia inmutable del inventario
     */
    getInventory() {
      return this._getInventorySnapshot();
    }
  
    // ========== MÉTODOS PRIVADOS ==========
  
    _validateName(name) {
      if (typeof name !== 'string' || !name.trim()) {
        throw new Error('El nombre debe ser un texto no vacío');
      }
      if (name.length > 100) {
        throw new Error('El nombre no puede exceder 100 caracteres');
      }
      if (/[^a-zA-Z0-9 áéíóúñÁÉÍÓÚÑ\-_]/g.test(name)) {
        throw new Error('El nombre contiene caracteres inválidos');
      }
    }
  
    _validateQuantity(quantity) {
      if (typeof quantity !== 'number' || isNaN(quantity)) {
        throw new Error('La cantidad debe ser un número válido');
      }
      if (!Number.isInteger(quantity)) {
        throw new Error('La cantidad debe ser un número entero');
      }
      if (quantity < 0) {
        throw new Error('La cantidad no puede ser negativa');
      }
    }
  
    _getInventorySnapshot() {
      return { ...this._inventory };
    }
  
    _logOperation(action, item, quantity) {
      this._history.push({
        timestamp: new Date().toISOString(),
        action,
        item,
        quantity,
        snapshot: this._getInventorySnapshot()
      });
    }
  }
  
  module.exports = Inventory;